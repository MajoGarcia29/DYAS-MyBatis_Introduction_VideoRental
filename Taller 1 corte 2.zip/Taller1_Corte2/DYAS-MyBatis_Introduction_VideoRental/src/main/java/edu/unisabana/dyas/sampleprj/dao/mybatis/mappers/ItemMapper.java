package edu.unisabana.dyas.sampleprj.dao.mybatis.mappers;

import edu.unisabana.dyas.samples.entities.Item;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ItemMapper {

    List<Item> consultarItems();

    Item consultarItem(@Param("id") int id);

    void insertarItem(
            @Param("id") int id,
            @Param("nombre") String nombre,
            @Param("descripcion") String descripcion,
            @Param("fechaLanzamiento") String fechaLanzamiento,
            @Param("tarifaxDia") double tarifaxDia,
            @Param("formatoRenta") String formatoRenta,
            @Param("genero") String genero,
            @Param("tipoItemId") int tipoItemId
    );
}