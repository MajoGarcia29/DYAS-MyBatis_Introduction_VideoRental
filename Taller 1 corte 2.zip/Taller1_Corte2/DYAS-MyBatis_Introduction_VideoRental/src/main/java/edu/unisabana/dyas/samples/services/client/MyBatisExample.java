package edu.unisabana.dyas.samples.services.client;

import edu.unisabana.dyas.sampleprj.dao.mybatis.mappers.ClienteMapper;
import edu.unisabana.dyas.sampleprj.dao.mybatis.mappers.ItemMapper;
import edu.unisabana.dyas.samples.entities.Cliente;
import edu.unisabana.dyas.samples.entities.Item;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class MyBatisExample {

    private static SqlSessionFactory sqlSessionFactory;

    // Cargar configuración de MyBatis (Singleton)
    public static SqlSessionFactory getSqlSessionFactory() {
        if (sqlSessionFactory == null) {
            try (InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml")) {
                sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            } catch (IOException e) {
                throw new RuntimeException("Error cargando configuración MyBatis", e);
            }
        }
        return sqlSessionFactory;
    }

    public static void main(String[] args) throws SQLException {
        SqlSessionFactory sessionFactory = getSqlSessionFactory();

        try (SqlSession sqlss = sessionFactory.openSession()) {
            ClienteMapper clienteMapper = sqlss.getMapper(ClienteMapper.class);
            ItemMapper itemMapper = sqlss.getMapper(ItemMapper.class);

            int idCliente = 123456789;
            int idItem = 1;
            Date fechaInicio = Date.valueOf("2025-09-06");
            Date fechaFin = Date.valueOf("2025-09-10");

            // 1. Insertar un item rentado a un cliente
            System.out.println("\n--- Insertar ItemRentado a un Cliente ---");
            clienteMapper.agregarItemRentadoACliente(idCliente, idItem, fechaInicio, fechaFin);
            System.out.println("✔ Item rentado agregado al cliente con documento " + idCliente);

            // 2. Consultar todos los clientes con sus items rentados
            System.out.println("\n--- Consultar todos los Clientes ---");
            List<Cliente> clientes = clienteMapper.consultarClientes();
            for (Cliente c : clientes) {
                System.out.println("Cliente: " + c.getNombre() + " | Documento: " + c.getDocumento());
                if (c.getRentados() != null && !c.getRentados().isEmpty()) {
                    c.getRentados().forEach(itemR ->
                            System.out.println("   - Item rentado: " + itemR.getItem().getNombre()
                                    + " (Inicio: " + itemR.getFechainiciorenta()
                                    + ", Fin: " + itemR.getFechafinrenta() + ")"));
                }
            }

            // 3. Consultar un cliente específico por ID
            System.out.println("\n--- Consultar Cliente por Documento ---");
            Cliente cliente = clienteMapper.consultarCliente(idCliente);
            if (cliente != null) {
                System.out.println("Cliente: " + cliente.getNombre() + " | Documento: " + cliente.getDocumento());
            } else {
                System.out.println("⚠ No se encontró un cliente con documento " + idCliente);
            }

            // 4. Insertar un nuevo item usando parámetros individuales
            System.out.println("\n--- Insertar Nuevo Item ---");
            int nuevoId = 10; // Cambia si ya existe en la BD
            String nombre = "Televisor";
            String descripcion = "Televisor de 50 pulgadas";
            String fechaLanzamiento = "2025-09-06"; // Fecha en formato String para SQL
            double tarifaxDia = 5000.0; // ← Ahora es double
            String formatoRenta = "Diario";
            String genero = "Electrónica";
            int tipoItemId = 1;

            itemMapper.insertarItem(nuevoId, nombre, descripcion, fechaLanzamiento, tarifaxDia, formatoRenta, genero, tipoItemId);
            System.out.println("✔ Nuevo item insertado con éxito!");

            // 5. Consultar un item específico por ID
            System.out.println("\n--- Consultar Item por ID ---");
            Item item = itemMapper.consultarItem(1);
            if (item != null) {
                System.out.println("Item: " + item.getNombre() + " | Tarifa: " + item.getTarifaxDia());
            } else {
                System.out.println("⚠ No se encontró un item con ID 1");
            }

            // 6. Consultar todos los items disponibles
            System.out.println("\n--- Consultar todos los Items ---");
            List<Item> items = itemMapper.consultarItems();
            for (Item i : items) {
                System.out.println("Item: " + i.getNombre() + " | Género: " + i.getGenero());
            }

            // Confirmar cambios
            sqlss.commit();
        }
    }
}
