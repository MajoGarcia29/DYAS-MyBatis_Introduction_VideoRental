package edu.unisabana.dyas.sampleprj.dao.mybatis.mappers;

import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;

import edu.unisabana.dyas.samples.entities.Cliente;

/**
 *
 * @author cesarvefe
 */
public interface ClienteMapper {
    
    public Cliente consultarCliente(int id); 
    
    /**
     * Registrar un nuevo item rentado asociado al cliente identificado
     * con 'id' y relacionado con el item identificado con 'idit'
     */
    public void agregarItemRentadoACliente(
            @Param("id") int id, 
            @Param("idit") int idit, 
            @Param("fechainicio") Date fechainicio,
            @Param("fechafin") Date fechafin);

    /**
     * Consultar todos los clientes
     */
    public List<Cliente> consultarClientes();
}